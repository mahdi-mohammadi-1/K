"use client";
import Link from "next/link";
import { Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from "@/components/ui/accordion";
import { articles, photos, steps, type Bilingual } from "@/lib/site-data";
import { useSite } from "./site-context";

export function PageHero({ title, description, label }: { title: Bilingual; description: Bilingual; label: string }) {
  const { t, locale } = useSite();
  return <section className="page-hero"><div className="container"><nav className="breadcrumb" aria-label={t("مسیر صفحه", "Breadcrumb")}><Link href="/">{t("خانه", "Home")}</Link><span aria-hidden="true">/</span><span aria-current="page">{title[locale]}</span></nav><div className="page-hero-row"><div><span className="page-label" dir="ltr">{label}</span><h1 className="display">{title[locale]}</h1></div><p className="body-copy">{description[locale]}</p></div></div></section>;
}

export function DemoNotice({ children }: { children?: React.ReactNode }) {
  const { t } = useSite();
  return <div className="demo-notice"><Info aria-hidden="true"/><span>{children || t("این بخش محتوای نمایشی دارد و پیش از انتشار رسمی، به تأیید شرکت نیاز دارد.", "This section contains demonstration content and needs company approval before an official launch.")}</span></div>;
}

export function CtaBand() {
  const { t } = useSite();
  return <section className="cta-band"><div className="container cta-inner"><div><span className="eyebrow">{t("آغاز یک گفتگو", "START A CONVERSATION")}</span><h2 className="section-title">{t("نیاز تجارتی شما چیست؟", "What does your business need?")}</h2><p>{t("از توضیح نیاز شما، به یک گفتگوی روشن درباره همکاری می‌رسیم.", "A clear description of your needs is the start of a useful conversation.")}</p></div><div className="button-row"><Button asChild className="btn"><Link href="/contact">{t("درخواست همکاری", "Start an enquiry")}</Link></Button><Link className="text-link" href="/process">{t("آشنایی با شیوه همکاری", "How collaboration works")}</Link></div></div></section>;
}

export function ProcessSteps() {
  const { locale } = useSite();
  return <div className="process-grid">{steps.map((s, i) => <div className="process-item" key={s.title.en}><div className="num" aria-hidden="true">0{i + 1}</div><h3>{s.title[locale]}</h3><p>{s.description[locale]}</p></div>)}</div>;
}

export function NewsRows({ items = articles }: { items?: typeof articles }) {
  const { locale, t } = useSite();
  const category: Record<string, string> = { guide: t("راهنما", "Guide"), insight: t("دیدگاه", "Insight"), activity: t("فعالیت نمونه", "Sample activity") };
  return <div className="news-list">{items.map(a => <Link className="news-row" href={`/news/${a.slug}`} key={a.slug}><img src={photos[a.image as keyof typeof photos]} width="106" height="86" loading="lazy" alt=""/><div><span className="news-tag">{category[a.category]} · {t("دیمو", "Demo")}</span><h3>{a.title[locale]}</h3><p>{a.excerpt[locale]}</p></div><div className="news-meta"><time dateTime={a.date}>{new Intl.DateTimeFormat(locale === "fa" ? "fa-AF" : "en-GB", { day: "numeric", month: "long", year: "numeric", timeZone: "UTC" }).format(new Date(a.date))}</time></div></Link>)}</div>;
}

export function Faq({ items }: { items: { question: Bilingual; answer: Bilingual }[] }) {
  const { locale, t } = useSite();
  return <section className="section-sm"><span className="eyebrow">{t("پرسش‌های معمول", "COMMON QUESTIONS")}</span><h2 className="section-title mb-5">{t("پیش از شروع همکاری", "Before we begin")}</h2><Accordion type="single" collapsible>{items.map((item, i) => <AccordionItem value={`question-${i}`} key={item.question.en}><AccordionTrigger className="faq-trigger">{item.question[locale]}</AccordionTrigger><AccordionContent className="faq-content">{item.answer[locale]}</AccordionContent></AccordionItem>)}</Accordion></section>;
}
