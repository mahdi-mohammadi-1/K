"use client";
import { createContext, useContext, useEffect, useSyncExternalStore } from "react";
import type { Locale } from "@/lib/site-data";
type SiteContextType = { locale: Locale; setLocale: (value: Locale) => void; t: (fa: string, en: string) => string };
const SiteContext = createContext<SiteContextType>({locale:"fa",setLocale:()=>{},t:(fa)=>fa});
let memoryLocale:Locale="fa";
const localeListeners=new Set<()=>void>();
const readLocale=():Locale=>{try{const saved=localStorage.getItem("kb-locale");return saved==="fa"||saved==="en"?saved:memoryLocale;}catch{return memoryLocale;}};
const serverLocale=():Locale=>"fa";
function subscribeLocale(listener:()=>void){localeListeners.add(listener);window.addEventListener("storage",listener);return ()=>{localeListeners.delete(listener);window.removeEventListener("storage",listener);};}
export function SiteProvider({children}:{children:React.ReactNode}){
  const locale=useSyncExternalStore(subscribeLocale,readLocale,serverLocale);
  useEffect(()=>{document.documentElement.lang=locale;document.documentElement.dir=locale==="fa"?"rtl":"ltr"},[locale]);
  const setLocale=(value:Locale)=>{memoryLocale=value;try{localStorage.setItem("kb-locale",value)}catch{}localeListeners.forEach(listener=>listener());};
  return <SiteContext.Provider value={{locale,setLocale,t:(fa,en)=>locale==="fa"?fa:en}}>{children}</SiteContext.Provider>;
}
export const useSite=()=>useContext(SiteContext);
