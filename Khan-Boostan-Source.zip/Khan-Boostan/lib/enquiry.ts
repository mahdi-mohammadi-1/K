import { z } from "zod";

export const normaliseDigits = (value: string) => value.replace(/[۰-۹]/g, n => String("۰۱۲۳۴۵۶۷۸۹".indexOf(n))).replace(/[٠-٩]/g, n => String("٠١٢٣٤٥٦٧٨٩".indexOf(n)));
export const contactIsValid = (value: string) => {
  const contact = normaliseDigits(value.trim());
  return z.string().email().safeParse(contact).success || (/^\+?[\d\s()\-]+$/.test(contact) && contact.replace(/\D/g, "").length >= 7 && contact.replace(/\D/g, "").length <= 15);
};
export const enquirySchema = z.object({
  name: z.string().trim().min(2, "name").max(100, "length"),
  company: z.string().trim().max(150, "length"),
  contact: z.string().trim().max(150, "length").refine(contactIsValid, "contact"),
  service: z.enum(["import", "export", "cooperation"]),
  product: z.string().trim().min(2, "product").max(250, "length"),
  quantity: z.string().trim().max(100, "length"),
  origin: z.string().trim().max(100, "length"),
  destination: z.string().trim().max(100, "length"),
  notes: z.string().trim().max(3000, "length"),
  demoConsent: z.boolean().refine(value => value, "consent"),
});
export type Enquiry = z.infer<typeof enquirySchema>;
export const initialEnquiry: Enquiry = { name: "", company: "", contact: "", service: "cooperation", product: "", quantity: "", origin: "", destination: "", notes: "", demoConsent: false };
export const draftEnquirySchema = z.object({
  name: z.string().max(100).optional(), company: z.string().max(150).optional(), contact: z.string().max(150).optional(),
  service: z.enum(["import", "export", "cooperation"]).optional(), product: z.string().max(250).optional(),
  quantity: z.string().max(100).optional(), origin: z.string().max(100).optional(), destination: z.string().max(100).optional(), notes: z.string().max(3000).optional(),
}).strict();
