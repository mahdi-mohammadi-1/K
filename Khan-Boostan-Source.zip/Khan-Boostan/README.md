# Khan Boostan — corporate frontend

A responsive React corporate website in Dari (RTL) and English, built with the Vinext app router, TypeScript, Tailwind CSS and the supplied accessible Radix / shadcn components.

## Pages

- Home: company introduction, two trade services, proposed process and demo journal.
- About: company description, principles and clearly labelled illustrative case study.
- Import and Export: independent service pages with enquiry links and FAQs.
- Process: four proposed steps, explicitly pending company approval.
- Journal: category filtering and three article detail pages.
- Contact: validated local demo form, optional local file selection, editable summary and JSON download.
- Custom not-found page.

## Development

Use Node 22.13 or later and the package manager pinned in package.json. Run `pnpm install`, then `pnpm dev`. Run `pnpm build` for a production build. In the managed Sites environment use the provided project setup, dependency installer and sites-preview supervisor.

## Content and data

The only supplied business facts are the company name and its request-driven import/export activity. No product catalogue, verified address, phone, email, licence, historical results or partner names were provided. These are not invented. All journal entries, dates, case-study scenarios and the proposed cooperation process are clearly identified as demonstration content. Replace and approve them before a public company launch.

All three freight/paperwork images are AI-generated illustrative scenes, not evidence of company facilities or transactions. Local WebP assets avoid third-party image requests. The typographic KB mark is a placeholder identity, not a supplied official logo.

The enquiry form has no application backend and does not send, upload, email, save remotely or create an order. Selected file contents are never read or uploaded; only the filename is included in the local downloadable summary. Personal enquiry data lives in React memory and clears on reload. Only the language preference uses localStorage. There are no analytics, payment flows or third-party services.

An optional feature-detected `stage_trade_enquiry` WebMCP tool fills the visible draft only. It validates inputs, does not acknowledge the demo notice or submit, and unregisters when the contact page unmounts. Browsers without WebMCP work normally.

## Where to edit

- `lib/site-data.ts`: shared navigation, process text and demo articles.
- `components/site/pages.tsx`: corporate page layouts and bilingual copy.
- `components/site/contact.tsx`: enquiry UI and local demo actions.
- `lib/enquiry.ts`: shared validation and draft schema.
- `app/globals.css`: visual theme and responsive layout.

Demo metadata prevents indexing. The initial Site publication is private.

## Verification

TypeScript and the application ESLint error checks passed. Pure validation checks cover blank and valid forms, consent, international contacts, Persian/Arabic digits and invalid draft fields. The internal browser preview verified the initial layout, invalid-field messages and focus, and the valid local enquiry summary. The current preview browser exposes no registered WebMCP tools; end-to-end WebMCP validation is therefore unavailable. The site remains fully usable through its visible interface.

Arabic typography uses locally hosted Noto Sans Arabic, distributed under the SIL Open Font License included in `public/fonts/OFL.txt`.
