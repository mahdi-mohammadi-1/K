import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { ArticlePage } from "@/components/site/pages";
import { articles } from "@/lib/site-data";
export function generateStaticParams(){return articles.map(a=>({slug:a.slug}));}
export async function generateMetadata({params}:{params:Promise<{slug:string}>}):Promise<Metadata>{const {slug}=await params;return {title:articles.find(a=>a.slug===slug)?.title.fa || "نوشته پیدا نشد"};}
export default async function Page({params}:{params:Promise<{slug:string}>}){const {slug}=await params;if(!articles.some(a=>a.slug===slug))notFound();return <ArticlePage slug={slug}/>;}
