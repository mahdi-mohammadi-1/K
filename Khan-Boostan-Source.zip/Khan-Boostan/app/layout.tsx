import type { Metadata } from "next";
import "./globals.css";
import { SiteProvider } from "@/components/site/site-context";
import { SiteHeader, SiteFooter } from "@/components/site/shell";

export const metadata: Metadata = {
  title: { default: "خان بوستان | واردات و صادرات", template: "%s | خان بوستان" },
  description: "شرکت تجارتی خان بوستان؛ واردات و صادرات بر اساس درخواست مشتری و نیاز بازار. نسخه نمایشی فرانت‌اند.",
  robots: { index: false, follow: false },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fa" dir="rtl" suppressHydrationWarning>
      <body className="antialiased"><SiteProvider><SiteHeader/>{children}<SiteFooter/></SiteProvider></body>
    </html>
  );
}
