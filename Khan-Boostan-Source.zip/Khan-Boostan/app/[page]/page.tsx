import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { AboutPage, ServicePage, ProcessPage, NewsPage } from "@/components/site/pages";
import { ContactPage } from "@/components/site/contact";
import { routes } from "@/lib/site-data";

const pages=["about","import","export","process","news","contact"];
export function generateStaticParams(){return pages.map(page=>({page}));}
export async function generateMetadata({params}:{params:Promise<{page:string}>}):Promise<Metadata>{const {page}=await params;return {title:routes.find(r=>r.href===`/${page}`)?.title.fa || "صفحه پیدا نشد"};}
export default async function Page({params,searchParams}:{params:Promise<{page:string}>;searchParams:Promise<{service?:string}>}){
  const {page}=await params;
  if(page==="contact"){const {service}=await searchParams;return <ContactPage initialService={service==="import"||service==="export"?service:"cooperation"}/>;}
  switch(page){case "about":return <AboutPage/>;case "import":return <ServicePage kind="import"/>;case "export":return <ServicePage kind="export"/>;case "process":return <ProcessPage/>;case "news":return <NewsPage/>;default:notFound();}
}
